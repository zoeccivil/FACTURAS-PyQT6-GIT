import { useState } from 'react';
import { ReporteMensual } from './components/ReporteMensual';
import { ReporteRetenciones } from './components/ReporteRetenciones';
import { ReporteImpuestos } from './components/ReporteImpuestos';
import { FileText, Receipt, Calculator } from 'lucide-react';

export default function App() {
  const [activeReport, setActiveReport] = useState<'mensual' | 'retenciones' | 'impuestos'>('mensual');

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-slate-900">Gestión Facturas PRO</h1>
              <p className="text-slate-600 text-sm mt-1">Sistema de Reportes Profesionales</p>
            </div>
            <div className="text-right">
              <p className="text-slate-500 text-sm">Diseños de Referencia</p>
              <p className="text-slate-400 text-xs">Mockups para Implementación PDF</p>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-6 py-6">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-2 inline-flex gap-2">
          <button
            onClick={() => setActiveReport('mensual')}
            className={`px-6 py-3 rounded-lg flex items-center gap-2 transition-all ${
              activeReport === 'mensual'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <FileText className="w-5 h-5" />
            Reporte Mensual
          </button>
          <button
            onClick={() => setActiveReport('retenciones')}
            className={`px-6 py-3 rounded-lg flex items-center gap-2 transition-all ${
              activeReport === 'retenciones'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <Receipt className="w-5 h-5" />
            Cálculo Retenciones
          </button>
          <button
            onClick={() => setActiveReport('impuestos')}
            className={`px-6 py-3 rounded-lg flex items-center gap-2 transition-all ${
              activeReport === 'impuestos'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <Calculator className="w-5 h-5" />
            Impuestos Multi-moneda
          </button>
        </div>
      </div>

      {/* Report Display */}
      <div className="max-w-7xl mx-auto px-6 pb-12">
        <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
          {activeReport === 'mensual' && <ReporteMensual />}
          {activeReport === 'retenciones' && <ReporteRetenciones />}
          {activeReport === 'impuestos' && <ReporteImpuestos />}
        </div>
      </div>
    </div>
  );
}
