import { Calculator, Calendar, TrendingUp, Globe2, DollarSign, Building2, BadgeDollarSign } from 'lucide-react';

export function ReporteImpuestos() {
  const facturas = [
    { fecha: '2024-11-05', numero: 'F-2024-078', empresa: 'Global Trading Corp', moneda: 'USD', tasa: '58.50', totalOrigen: '5,240.00', totalRD: '306,540.00', impuestosOrigen: '524.00', impuestosRD: '30,654.00' },
    { fecha: '2024-11-08', numero: 'F-2024-079', empresa: 'Constructora Nacional SRL', moneda: 'RD$', tasa: '1.00', totalOrigen: '450,000.00', totalRD: '450,000.00', impuestosOrigen: '81,000.00', impuestosRD: '81,000.00' },
    { fecha: '2024-11-12', numero: 'F-2024-080', empresa: 'European Imports SA', moneda: 'EUR', tasa: '62.80', totalOrigen: '3,150.00', totalRD: '197,820.00', impuestosOrigen: '315.00', impuestosRD: '19,782.00' },
    { fecha: '2024-11-15', numero: 'F-2024-081', empresa: 'Tech Solutions RD', moneda: 'USD', tasa: '58.75', totalOrigen: '8,900.00', totalRD: '522,875.00', impuestosOrigen: '890.00', impuestosRD: '52,287.50' },
    { fecha: '2024-11-19', numero: 'F-2024-082', empresa: 'Distribuidora La Capital', moneda: 'RD$', tasa: '1.00', totalOrigen: '320,500.00', totalRD: '320,500.00', impuestosOrigen: '57,690.00', impuestosRD: '57,690.00' },
    { fecha: '2024-11-22', numero: 'F-2024-083', empresa: 'American Partners LLC', moneda: 'USD', tasa: '59.00', totalOrigen: '12,450.00', totalRD: '734,550.00', impuestosOrigen: '1,245.00', impuestosRD: '73,455.00' },
    { fecha: '2024-11-26', numero: 'F-2024-084', empresa: 'Servicios Profesionales', moneda: 'RD$', tasa: '1.00', totalOrigen: '180,000.00', totalRD: '180,000.00', impuestosOrigen: '32,400.00', impuestosRD: '32,400.00' },
    { fecha: '2024-11-28', numero: 'F-2024-085', empresa: 'Nordic Trade Group', moneda: 'EUR', tasa: '63.20', totalOrigen: '4,800.00', totalRD: '303,360.00', impuestosOrigen: '480.00', impuestosRD: '30,336.00' }
  ];

  const resumenMonedas = [
    { moneda: 'USD', simbolo: '$', total: 26590.00, impuestos: 2659.00, facturas: 3, color: 'green' },
    { moneda: 'EUR', simbolo: '€', total: 7950.00, impuestos: 795.00, facturas: 2, color: 'blue' },
    { moneda: 'RD$', simbolo: 'RD$', total: 950500.00, impuestos: 171090.00, facturas: 3, color: 'indigo' }
  ];

  const totalImpuestosUSD = 156396.50;
  const totalImpuestosEUR = 50118.00;
  const totalImpuestosRD = 171090.00;
  const granTotalRD = 377604.50;
  const porcentajePagar = 15;

  return (
    <div className="p-12 bg-white">
      {/* Header */}
      <div className="border-b border-slate-200 pb-8 mb-10">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-14 h-14 bg-gradient-to-br from-indigo-600 via-purple-600 to-indigo-700 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-300">
                <Calculator className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-slate-900">Reporte de Cálculo de Impuestos</h1>
                <p className="text-slate-600 mt-1">Operaciones Multi-moneda</p>
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="bg-gradient-to-r from-slate-100 to-slate-50 border border-slate-200 px-5 py-3 rounded-xl">
              <p className="text-xs text-slate-600 uppercase tracking-wide mb-1">Periodo</p>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-slate-600" />
                <span className="text-slate-900">1 Nov - 30 Nov 2024</span>
              </div>
            </div>
            <p className="text-slate-500 text-xs mt-3">Generado: 7 Diciembre, 2024</p>
          </div>
        </div>
      </div>

      {/* Top Stats */}
      <div className="grid grid-cols-4 gap-5 mb-10">
        <div className="bg-gradient-to-br from-purple-50 to-indigo-50 border border-purple-200 rounded-xl p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <Globe2 className="w-5 h-5 text-purple-700" />
            </div>
            <p className="text-xs text-purple-700 uppercase tracking-wide">Monedas</p>
          </div>
          <p className="text-3xl text-purple-900">3</p>
        </div>

        <div className="bg-gradient-to-br from-blue-50 to-cyan-50 border border-blue-200 rounded-xl p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <Building2 className="w-5 h-5 text-blue-700" />
            </div>
            <p className="text-xs text-blue-700 uppercase tracking-wide">Facturas</p>
          </div>
          <p className="text-3xl text-blue-900">{facturas.length}</p>
        </div>

        <div className="bg-gradient-to-br from-emerald-50 to-green-50 border border-emerald-200 rounded-xl p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-emerald-700" />
            </div>
            <p className="text-xs text-emerald-700 uppercase tracking-wide">Total Operado</p>
          </div>
          <p className="text-2xl text-emerald-900">RD$ 3.0M</p>
        </div>

        <div className="bg-gradient-to-br from-orange-50 to-amber-50 border border-orange-200 rounded-xl p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
              <BadgeDollarSign className="w-5 h-5 text-orange-700" />
            </div>
            <p className="text-xs text-orange-700 uppercase tracking-wide">% a Pagar</p>
          </div>
          <p className="text-3xl text-orange-900">{porcentajePagar}%</p>
        </div>
      </div>

      {/* Facturas Table */}
      <div className="mb-10">
        <h2 className="text-slate-900 mb-5">Detalle de Facturas</h2>
        <div className="border border-slate-200 rounded-xl overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gradient-to-r from-slate-700 to-slate-800 text-white">
                  <th className="px-4 py-4 text-left text-xs uppercase tracking-wider">Fecha</th>
                  <th className="px-4 py-4 text-left text-xs uppercase tracking-wider">No. Factura</th>
                  <th className="px-4 py-4 text-left text-xs uppercase tracking-wider">Empresa</th>
                  <th className="px-4 py-4 text-center text-xs uppercase tracking-wider">Moneda</th>
                  <th className="px-4 py-4 text-right text-xs uppercase tracking-wider">Tasa</th>
                  <th className="px-4 py-4 text-right text-xs uppercase tracking-wider">Total (Origen)</th>
                  <th className="px-4 py-4 text-right text-xs uppercase tracking-wider">Total (RD$)</th>
                  <th className="px-4 py-4 text-right text-xs uppercase tracking-wider">Impuestos (Origen)</th>
                  <th className="px-4 py-4 text-right text-xs uppercase tracking-wider">Impuestos (RD$)</th>
                </tr>
              </thead>
              <tbody>
                {facturas.map((factura, index) => {
                  const monedaColors: { [key: string]: { bg: string; text: string; border: string } } = {
                    'USD': { bg: 'bg-green-50', text: 'text-green-700', border: 'border-green-200' },
                    'EUR': { bg: 'bg-blue-50', text: 'text-blue-700', border: 'border-blue-200' },
                    'RD$': { bg: 'bg-indigo-50', text: 'text-indigo-700', border: 'border-indigo-200' }
                  };
                  const colors = monedaColors[factura.moneda];

                  return (
                    <tr 
                      key={index} 
                      className={`${index % 2 === 0 ? 'bg-white' : 'bg-slate-50'} border-b border-slate-100 last:border-0 hover:bg-slate-100/50 transition-colors`}
                    >
                      <td className="px-4 py-4 text-sm text-slate-600">{factura.fecha}</td>
                      <td className="px-4 py-4">
                        <span className="text-xs text-slate-700 bg-slate-100 px-2.5 py-1 rounded border border-slate-200">
                          {factura.numero}
                        </span>
                      </td>
                      <td className="px-4 py-4 text-sm text-slate-900">{factura.empresa}</td>
                      <td className="px-4 py-4 text-center">
                        <span className={`text-xs px-2.5 py-1 rounded-full border ${colors.bg} ${colors.text} ${colors.border}`}>
                          {factura.moneda}
                        </span>
                      </td>
                      <td className="px-4 py-4 text-sm text-right text-slate-700">{factura.tasa}</td>
                      <td className="px-4 py-4 text-sm text-right text-slate-900">{factura.totalOrigen}</td>
                      <td className="px-4 py-4 text-sm text-right text-slate-900">{factura.totalRD}</td>
                      <td className="px-4 py-4 text-sm text-right text-indigo-700">{factura.impuestosOrigen}</td>
                      <td className="px-4 py-4 text-sm text-right text-indigo-900">{factura.impuestosRD}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Resumen por Moneda */}
      <div className="mb-10">
        <h2 className="text-slate-900 mb-5">Resumen por Moneda</h2>
        <div className="grid grid-cols-3 gap-6">
          {resumenMonedas.map((item, index) => {
            const cardColors: { [key: string]: { bg: string; border: string; badge: string; badgeBorder: string } } = {
              'green': { 
                bg: 'bg-gradient-to-br from-green-50 to-emerald-50', 
                border: 'border-green-200',
                badge: 'bg-green-100',
                badgeBorder: 'border-green-300'
              },
              'blue': { 
                bg: 'bg-gradient-to-br from-blue-50 to-cyan-50', 
                border: 'border-blue-200',
                badge: 'bg-blue-100',
                badgeBorder: 'border-blue-300'
              },
              'indigo': { 
                bg: 'bg-gradient-to-br from-indigo-50 to-purple-50', 
                border: 'border-indigo-200',
                badge: 'bg-indigo-100',
                badgeBorder: 'border-indigo-300'
              }
            };
            const colors = cardColors[item.color];

            return (
              <div key={index} className={`${colors.bg} border ${colors.border} rounded-xl p-6 shadow-sm`}>
                <div className="flex items-center justify-between mb-4">
                  <span className={`text-2xl px-3 py-1 rounded-lg border ${colors.badge} ${colors.badgeBorder}`}>
                    {item.moneda}
                  </span>
                  <span className="text-xs text-slate-600 bg-white/60 px-2.5 py-1 rounded-full">
                    {item.facturas} facturas
                  </span>
                </div>
                
                <div className="space-y-3">
                  <div className="pb-3 border-b border-slate-300/50">
                    <p className="text-xs text-slate-600 uppercase tracking-wide mb-1">Total Operado</p>
                    <p className="text-xl text-slate-900">
                      {item.simbolo} {item.total.toLocaleString('es-DO', { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                  
                  <div>
                    <p className="text-xs text-slate-600 uppercase tracking-wide mb-1">Impuestos</p>
                    <p className="text-2xl text-slate-900">
                      {item.simbolo} {item.impuestos.toLocaleString('es-DO', { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Conversión a RD$ */}
      <div className="mb-10">
        <h2 className="text-slate-900 mb-5">Impuestos Convertidos a RD$</h2>
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-white border-2 border-green-200 rounded-lg p-5">
            <p className="text-sm text-slate-600 mb-2">USD → RD$</p>
            <p className="text-2xl text-green-700">RD$ {totalImpuestosUSD.toLocaleString('es-DO', { minimumFractionDigits: 2 })}</p>
          </div>
          <div className="bg-white border-2 border-blue-200 rounded-lg p-5">
            <p className="text-sm text-slate-600 mb-2">EUR → RD$</p>
            <p className="text-2xl text-blue-700">RD$ {totalImpuestosEUR.toLocaleString('es-DO', { minimumFractionDigits: 2 })}</p>
          </div>
          <div className="bg-white border-2 border-indigo-200 rounded-lg p-5">
            <p className="text-sm text-slate-600 mb-2">RD$ → RD$</p>
            <p className="text-2xl text-indigo-700">RD$ {totalImpuestosRD.toLocaleString('es-DO', { minimumFractionDigits: 2 })}</p>
          </div>
        </div>

        {/* Gran Total */}
        <div className="bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-700 rounded-2xl p-10 shadow-2xl shadow-indigo-300 border-2 border-indigo-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-indigo-100 uppercase tracking-wider mb-3 flex items-center gap-3">
                <DollarSign className="w-6 h-6" />
                Gran Total (Convertido a RD$)
              </p>
              <p className="text-6xl text-white mb-4">
                RD$ {granTotalRD.toLocaleString('es-DO', { minimumFractionDigits: 2 })}
              </p>
              <div className="flex items-center gap-6">
                <div className="bg-white/20 backdrop-blur rounded-lg px-4 py-2">
                  <p className="text-indigo-100 text-xs mb-1">Porcentaje a Pagar</p>
                  <p className="text-white text-xl">{porcentajePagar}%</p>
                </div>
                <div className="bg-white/20 backdrop-blur rounded-lg px-4 py-2">
                  <p className="text-indigo-100 text-xs mb-1">Monto a Pagar</p>
                  <p className="text-white text-xl">RD$ {(granTotalRD * porcentajePagar / 100).toLocaleString('es-DO', { minimumFractionDigits: 2 })}</p>
                </div>
              </div>
            </div>
            <div className="w-24 h-24 bg-white/20 backdrop-blur rounded-3xl flex items-center justify-center">
              <Calculator className="w-12 h-12 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Information Box */}
      <div className="bg-amber-50 border border-amber-200 rounded-xl p-6 mb-8">
        <div className="flex gap-4">
          <div className="flex-shrink-0">
            <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center">
              <Globe2 className="w-5 h-5 text-amber-700" />
            </div>
          </div>
          <div>
            <p className="text-sm text-amber-900 mb-2">Información sobre Conversiones</p>
            <p className="text-sm text-amber-800 leading-relaxed">
              Las tasas de cambio utilizadas corresponden a las tasas oficiales del Banco Central al momento de cada transacción. 
              Los cálculos han sido realizados de acuerdo a las normativas fiscales vigentes para operaciones en múltiples monedas. 
              Este reporte debe ser revisado por el departamento contable antes de cualquier declaración oficial.
            </p>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="mt-8 pt-6 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
        <p>Gestión Facturas PRO - Reporte de Impuestos Multi-moneda</p>
        <p>Documento Confidencial - Página 1 de 1</p>
      </div>
    </div>
  );
}
