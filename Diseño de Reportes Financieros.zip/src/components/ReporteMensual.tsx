import { TrendingUp, TrendingDown, DollarSign, FileText, Calendar, Building2 } from 'lucide-react';

export function ReporteMensual() {
  const kpis = [
    {
      label: 'Total Ingresos',
      value: 'RD$ 1,245,680.00',
      icon: TrendingUp,
      color: 'green',
      change: '+12.5%'
    },
    {
      label: 'Total Gastos',
      value: 'RD$ 458,920.00',
      icon: TrendingDown,
      color: 'red',
      change: '-8.3%'
    },
    {
      label: 'Total Neto',
      value: 'RD$ 786,760.00',
      icon: DollarSign,
      color: 'indigo',
      change: '+25.1%'
    }
  ];

  const impuestos = [
    { label: 'ITBIS Ingresos', value: 'RD$ 224,222.40', color: 'blue' },
    { label: 'ITBIS Gastos', value: 'RD$ 82,605.60', color: 'orange' },
    { label: 'ITBIS Neto', value: 'RD$ 141,616.80', color: 'emerald' }
  ];

  const facturasEmitidas = [
    { fecha: '2024-12-01', numero: 'F-2024-001', cliente: 'Constructora Del Este, SRL', itbis: '15,240.00', total: '99,780.00' },
    { fecha: '2024-12-05', numero: 'F-2024-002', cliente: 'Supermercados La Cadena', itbis: '28,560.00', total: '187,080.00' },
    { fecha: '2024-12-10', numero: 'F-2024-003', cliente: 'Tech Solutions RD', itbis: '9,180.00', total: '60,120.00' },
    { fecha: '2024-12-15', numero: 'F-2024-004', cliente: 'Importadora Global', itbis: '42,840.00', total: '280,560.00' },
    { fecha: '2024-12-20', numero: 'F-2024-005', cliente: 'Distribuidora Nacional', itbis: '18,360.00', total: '120,240.00' }
  ];

  const facturasGastos = [
    { fecha: '2024-12-03', numero: 'G-2024-015', proveedor: 'Materiales Industriales SA', itbis: '12,420.00', total: '81,380.00' },
    { fecha: '2024-12-08', numero: 'G-2024-016', proveedor: 'Servicios Profesionales RD', itbis: '5,580.00', total: '36,540.00' },
    { fecha: '2024-12-12', numero: 'G-2024-017', proveedor: 'Alquiler Equipos Tech', itbis: '8,940.00', total: '58,560.00' },
    { fecha: '2024-12-18', numero: 'G-2024-018', proveedor: 'Mantenimiento Industrial', itbis: '4,260.00', total: '27,900.00' }
  ];

  return (
    <div className="p-12 bg-white">
      {/* Header */}
      <div className="border-b border-slate-200 pb-8 mb-8">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 bg-indigo-600 rounded-lg flex items-center justify-center">
                <FileText className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-slate-900">Reporte Mensual de Facturación</h1>
                <div className="flex items-center gap-4 mt-1">
                  <div className="flex items-center gap-1.5 text-slate-600 text-sm">
                    <Calendar className="w-4 h-4" />
                    <span>Diciembre 2024</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-600 text-sm">
                    <Building2 className="w-4 h-4" />
                    <span>Mi Empresa SRL</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="text-right">
            <p className="text-slate-500 text-sm">Generado</p>
            <p className="text-slate-900">7 Diciembre, 2024</p>
          </div>
        </div>
      </div>

      {/* KPIs Grid */}
      <div className="mb-10">
        <h2 className="text-slate-900 mb-4">Resumen Ejecutivo</h2>
        <div className="grid grid-cols-3 gap-6">
          {kpis.map((kpi, index) => {
            const Icon = kpi.icon;
            const colorClasses = {
              green: 'bg-green-50 text-green-700 border-green-200',
              red: 'bg-red-50 text-red-700 border-red-200',
              indigo: 'bg-indigo-50 text-indigo-700 border-indigo-200'
            };
            const iconBgClasses = {
              green: 'bg-green-100',
              red: 'bg-red-100',
              indigo: 'bg-indigo-100'
            };
            const iconColorClasses = {
              green: 'text-green-700',
              red: 'text-red-700',
              indigo: 'text-indigo-700'
            };

            return (
              <div
                key={index}
                className={`border rounded-xl p-6 ${colorClasses[kpi.color as keyof typeof colorClasses]}`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${iconBgClasses[kpi.color as keyof typeof iconBgClasses]}`}>
                    <Icon className={`w-5 h-5 ${iconColorClasses[kpi.color as keyof typeof iconColorClasses]}`} />
                  </div>
                  <span className="text-xs px-2 py-1 bg-white/60 rounded-full">{kpi.change}</span>
                </div>
                <p className="text-sm opacity-80 mb-1">{kpi.label}</p>
                <p className="text-2xl">{kpi.value}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* ITBIS Summary */}
      <div className="mb-10">
        <h2 className="text-slate-900 mb-4">Resumen de ITBIS</h2>
        <div className="grid grid-cols-3 gap-4">
          {impuestos.map((item, index) => {
            const bgClasses = {
              blue: 'bg-blue-50 border-blue-200',
              orange: 'bg-orange-50 border-orange-200',
              emerald: 'bg-emerald-50 border-emerald-200'
            };
            const textClasses = {
              blue: 'text-blue-900',
              orange: 'text-orange-900',
              emerald: 'text-emerald-900'
            };
            const labelClasses = {
              blue: 'text-blue-700',
              orange: 'text-orange-700',
              emerald: 'text-emerald-700'
            };

            return (
              <div
                key={index}
                className={`border rounded-lg p-5 ${bgClasses[item.color as keyof typeof bgClasses]}`}
              >
                <p className={`text-sm mb-2 ${labelClasses[item.color as keyof typeof labelClasses]}`}>{item.label}</p>
                <p className={`text-xl ${textClasses[item.color as keyof typeof textClasses]}`}>{item.value}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Facturas Emitidas Table */}
      <div className="mb-10">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-slate-900">Facturas Emitidas</h2>
          <span className="text-sm text-slate-600 bg-slate-100 px-3 py-1.5 rounded-full">
            {facturasEmitidas.length} facturas
          </span>
        </div>
        <div className="border border-slate-200 rounded-xl overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="px-6 py-4 text-left text-xs text-slate-600 uppercase tracking-wider">Fecha</th>
                <th className="px-6 py-4 text-left text-xs text-slate-600 uppercase tracking-wider">No. Factura</th>
                <th className="px-6 py-4 text-left text-xs text-slate-600 uppercase tracking-wider">Cliente</th>
                <th className="px-6 py-4 text-right text-xs text-slate-600 uppercase tracking-wider">ITBIS RD$</th>
                <th className="px-6 py-4 text-right text-xs text-slate-600 uppercase tracking-wider">Total RD$</th>
              </tr>
            </thead>
            <tbody>
              {facturasEmitidas.map((factura, index) => (
                <tr key={index} className={`${index % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'} border-b border-slate-100 last:border-0`}>
                  <td className="px-6 py-4 text-sm text-slate-600">{factura.fecha}</td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-md">
                      {factura.numero}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-900">{factura.cliente}</td>
                  <td className="px-6 py-4 text-sm text-right text-slate-900">{factura.itbis}</td>
                  <td className="px-6 py-4 text-sm text-right text-slate-900">{factura.total}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="bg-indigo-50 border-t-2 border-indigo-200">
                <td colSpan={3} className="px-6 py-4 text-sm text-indigo-900">Total</td>
                <td className="px-6 py-4 text-sm text-right text-indigo-900">114,180.00</td>
                <td className="px-6 py-4 text-sm text-right text-indigo-900">747,780.00</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* Facturas de Gastos Table */}
      <div className="mb-10">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-slate-900">Facturas de Gastos</h2>
          <span className="text-sm text-slate-600 bg-slate-100 px-3 py-1.5 rounded-full">
            {facturasGastos.length} facturas
          </span>
        </div>
        <div className="border border-slate-200 rounded-xl overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="px-6 py-4 text-left text-xs text-slate-600 uppercase tracking-wider">Fecha</th>
                <th className="px-6 py-4 text-left text-xs text-slate-600 uppercase tracking-wider">No. Factura</th>
                <th className="px-6 py-4 text-left text-xs text-slate-600 uppercase tracking-wider">Proveedor</th>
                <th className="px-6 py-4 text-right text-xs text-slate-600 uppercase tracking-wider">ITBIS RD$</th>
                <th className="px-6 py-4 text-right text-xs text-slate-600 uppercase tracking-wider">Total RD$</th>
              </tr>
            </thead>
            <tbody>
              {facturasGastos.map((factura, index) => (
                <tr key={index} className={`${index % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'} border-b border-slate-100 last:border-0`}>
                  <td className="px-6 py-4 text-sm text-slate-600">{factura.fecha}</td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-orange-700 bg-orange-50 px-2.5 py-1 rounded-md">
                      {factura.numero}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-900">{factura.proveedor}</td>
                  <td className="px-6 py-4 text-sm text-right text-slate-900">{factura.itbis}</td>
                  <td className="px-6 py-4 text-sm text-right text-slate-900">{factura.total}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="bg-orange-50 border-t-2 border-orange-200">
                <td colSpan={3} className="px-6 py-4 text-sm text-orange-900">Total</td>
                <td className="px-6 py-4 text-sm text-right text-orange-900">31,200.00</td>
                <td className="px-6 py-4 text-sm text-right text-orange-900">204,380.00</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* Footer Notes */}
      <div className="border-t border-slate-200 pt-6">
        <div className="bg-slate-50 rounded-lg p-5 border border-slate-200">
          <p className="text-sm text-slate-700 mb-2">Notas y Comentarios</p>
          <p className="text-sm text-slate-600 leading-relaxed">
            Este reporte refleja todas las operaciones registradas durante el mes de diciembre 2024. 
            Los cálculos de ITBIS se han realizado automáticamente según las tasas vigentes. 
            Para consultas adicionales, contacte al departamento de contabilidad.
          </p>
        </div>
      </div>

      {/* Footer */}
      <div className="mt-8 pt-6 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
        <p>Gestión Facturas PRO - Sistema de Reportes Profesionales</p>
        <p>Página 1 de 1</p>
      </div>
    </div>
  );
}
