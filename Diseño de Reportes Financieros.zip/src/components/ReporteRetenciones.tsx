import { Receipt, Building2, Calendar, AlertCircle, CheckCircle2, Percent, DollarSign } from 'lucide-react';

export function ReporteRetenciones() {
  const facturas = [
    { fecha: '2024-11-15', numero: 'F-2024-087', empresa: 'Constructora Del Caribe SRL', total: '245,680.00', itbis: '44,222.40' },
    { fecha: '2024-11-18', numero: 'F-2024-088', empresa: 'Distribuidora Nacional SA', total: '189,420.00', itbis: '34,095.60' },
    { fecha: '2024-11-22', numero: 'F-2024-089', empresa: 'Importadora Global RD', total: '428,950.00', itbis: '77,211.00' },
    { fecha: '2024-11-25', numero: 'F-2024-090', empresa: 'Tech Solutions Dominicana', total: '156,780.00', itbis: '28,220.40' },
    { fecha: '2024-11-28', numero: 'F-2024-091', empresa: 'Supermercados La Cadena', total: '312,450.00', itbis: '56,241.00' },
    { fecha: '2024-11-30', numero: 'F-2024-092', empresa: 'Servicios Profesionales RD', total: '98,640.00', itbis: '17,755.20' }
  ];

  const totalGeneral = 1432920.00;
  const totalItbis = 257745.60;
  const porcentajeRetencionItbis = 30;
  const porcentajeRetencionTotal = 2;
  const retencionItbis = totalItbis * (porcentajeRetencionItbis / 100);
  const retencionTotal = totalGeneral * (porcentajeRetencionTotal / 100);
  const totalARetener = retencionItbis + retencionTotal;

  return (
    <div className="p-12 bg-white">
      {/* Header */}
      <div className="border-b border-slate-200 pb-8 mb-10">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-14 h-14 bg-gradient-to-br from-indigo-600 to-indigo-700 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-200">
                <Receipt className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-slate-900">Cálculo de Retenciones</h1>
                <p className="text-slate-600 mt-1">Periodo Fiscal - Noviembre 2024</p>
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="inline-flex items-center gap-2 bg-green-50 border border-green-200 px-4 py-2 rounded-lg">
              <CheckCircle2 className="w-5 h-5 text-green-700" />
              <span className="text-sm text-green-900">Cálculo Completo</span>
            </div>
            <p className="text-slate-500 text-xs mt-2">Generado: 7 Diciembre, 2024</p>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="mb-10">
        <h2 className="text-slate-900 mb-5">Resumen de Cálculo</h2>
        <div className="grid grid-cols-2 gap-6 mb-6">
          {/* Left Card - General Info */}
          <div className="bg-gradient-to-br from-slate-50 to-slate-100 border border-slate-200 rounded-xl p-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-xs text-slate-600 uppercase tracking-wide mb-2">Facturas Seleccionadas</p>
                <p className="text-3xl text-slate-900">{facturas.length}</p>
              </div>
              <div>
                <p className="text-xs text-slate-600 uppercase tracking-wide mb-2">Total General</p>
                <p className="text-2xl text-slate-900">RD$ {totalGeneral.toLocaleString('es-DO', { minimumFractionDigits: 2 })}</p>
              </div>
              <div className="col-span-2 border-t border-slate-300 pt-4 mt-2">
                <p className="text-xs text-slate-600 uppercase tracking-wide mb-2">Total ITBIS</p>
                <p className="text-2xl text-indigo-700">RD$ {totalItbis.toLocaleString('es-DO', { minimumFractionDigits: 2 })}</p>
              </div>
            </div>
          </div>

          {/* Right Card - Retention Percentages */}
          <div className="bg-gradient-to-br from-indigo-50 to-blue-50 border border-indigo-200 rounded-xl p-6">
            <p className="text-xs text-indigo-700 uppercase tracking-wide mb-4 flex items-center gap-2">
              <Percent className="w-4 h-4" />
              Porcentajes de Retención
            </p>
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-indigo-200">
                <span className="text-sm text-slate-700">Retención sobre ITBIS</span>
                <span className="text-xl text-indigo-900">{porcentajeRetencionItbis}%</span>
              </div>
              <div className="flex items-center justify-between pb-3 border-b border-indigo-200">
                <span className="text-sm text-slate-700">Retención sobre Total</span>
                <span className="text-xl text-indigo-900">{porcentajeRetencionTotal}%</span>
              </div>
              <div className="flex items-center justify-between pt-2">
                <span className="text-sm text-slate-700">Retención ITBIS</span>
                <span className="text-lg text-slate-900">RD$ {retencionItbis.toLocaleString('es-DO', { minimumFractionDigits: 2 })}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-700">Retención Total</span>
                <span className="text-lg text-slate-900">RD$ {retencionTotal.toLocaleString('es-DO', { minimumFractionDigits: 2 })}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Total a Retener - Statement Style */}
        <div className="bg-gradient-to-r from-red-600 to-red-700 rounded-xl p-8 shadow-xl shadow-red-200 border-2 border-red-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-red-100 text-sm uppercase tracking-wide mb-2 flex items-center gap-2">
                <DollarSign className="w-5 h-5" />
                Total a Retener
              </p>
              <p className="text-5xl text-white">
                RD$ {totalARetener.toLocaleString('es-DO', { minimumFractionDigits: 2 })}
              </p>
            </div>
            <div className="w-20 h-20 bg-white/20 backdrop-blur rounded-2xl flex items-center justify-center">
              <AlertCircle className="w-10 h-10 text-white" />
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-red-400/30">
            <p className="text-red-50 text-sm">
              Monto total a retener de acuerdo a las regulaciones fiscales vigentes
            </p>
          </div>
        </div>
      </div>

      {/* Facturas Table */}
      <div className="mb-10">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-slate-900">Facturas Incluidas en el Cálculo</h2>
          <span className="text-xs text-slate-600 bg-slate-100 px-3 py-1.5 rounded-full">
            Periodo: Noviembre 2024
          </span>
        </div>
        
        <div className="border border-slate-200 rounded-xl overflow-hidden shadow-sm">
          <table className="w-full">
            <thead>
              <tr className="bg-gradient-to-r from-slate-700 to-slate-800 text-white">
                <th className="px-6 py-4 text-left text-xs uppercase tracking-wider">Fecha</th>
                <th className="px-6 py-4 text-left text-xs uppercase tracking-wider">No. Factura</th>
                <th className="px-6 py-4 text-left text-xs uppercase tracking-wider">Empresa</th>
                <th className="px-6 py-4 text-right text-xs uppercase tracking-wider">ITBIS RD$</th>
                <th className="px-6 py-4 text-right text-xs uppercase tracking-wider">Total RD$</th>
              </tr>
            </thead>
            <tbody>
              {facturas.map((factura, index) => (
                <tr 
                  key={index} 
                  className={`${index % 2 === 0 ? 'bg-white' : 'bg-slate-50'} border-b border-slate-100 last:border-0 hover:bg-indigo-50/50 transition-colors`}
                >
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-sm text-slate-600">
                      <Calendar className="w-4 h-4" />
                      {factura.fecha}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-indigo-700 bg-indigo-50 px-3 py-1.5 rounded-lg border border-indigo-200">
                      {factura.numero}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-sm text-slate-900">
                      <Building2 className="w-4 h-4 text-slate-400" />
                      {factura.empresa}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-right text-slate-900">{factura.itbis}</td>
                  <td className="px-6 py-4 text-sm text-right text-slate-900">{factura.total}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="bg-gradient-to-r from-indigo-600 to-indigo-700 text-white">
                <td colSpan={3} className="px-6 py-5 uppercase tracking-wide">
                  Total General
                </td>
                <td className="px-6 py-5 text-right">
                  {totalItbis.toLocaleString('es-DO', { minimumFractionDigits: 2 })}
                </td>
                <td className="px-6 py-5 text-right">
                  {totalGeneral.toLocaleString('es-DO', { minimumFractionDigits: 2 })}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* Information Box */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
        <div className="flex gap-4">
          <div className="flex-shrink-0">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <AlertCircle className="w-5 h-5 text-blue-700" />
            </div>
          </div>
          <div>
            <p className="text-sm text-blue-900 mb-2">Información Importante</p>
            <p className="text-sm text-blue-800 leading-relaxed">
              Este cálculo refleja las retenciones fiscales aplicables según las normativas vigentes de la DGII. 
              Los montos deben ser declarados y pagados dentro del plazo establecido. Para más información, 
              consulte con su asesor fiscal o el departamento de contabilidad.
            </p>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="mt-8 pt-6 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
        <p>Gestión Facturas PRO - Cálculo de Retenciones Fiscales</p>
        <p>Documento Confidencial - Página 1 de 1</p>
      </div>
    </div>
  );
}
