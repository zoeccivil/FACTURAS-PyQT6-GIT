
  # Diseño de Reportes Financieros

  This is a code bundle for Diseño de Reportes Financieros. The original project is available at https://www.figma.com/design/iRsDyMyTjrr9bw5HsRIKpj/Dise%C3%B1o-de-Reportes-Financieros.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  